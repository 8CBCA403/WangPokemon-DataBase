from G8RNG import XOROSHIRO,Raid

def find_seed(seeds, ivs, iv_count):
    for seed in seeds:
        r = Raid(seed,iv_count)
        if ivs == r.IVs:
            return seed
    return None

def main():
    EC = 0x9DFFC477
    PID = 0x9C86F7F8
    IVs = [ 14, 31, 31, 31, 10, 24]
    iv_count = 3

    seeds = XOROSHIRO.find_seeds(EC, PID)    
    if len(seeds) > 0:
        seed = find_seed(seeds, IVs, iv_count)
        if seed != None:
            print(f"Raid seed: 0x{seed:016X}")
            return True

    seedsXor = XOROSHIRO.find_seeds(EC, PID ^ 0x10000000) # Check for shiny lock
    if len(seedsXor) > 0:
        seed = find_seed(seedsXor, IVs, iv_count)
        if seed != None:
            print(f"Raid seed (shiny locked): 0x{seed:016X}")
            return True

    return False

if __name__ == "__main__":
    if main() == False:
        print("No raid seed")