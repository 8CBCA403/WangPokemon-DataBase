from G8RNG import Raid

PID = 0x9af0752
EC = 0xeb9ad6ba
IVs = [31,31,28,31,11,31]

results = Raid.getseeds(EC,PID,IVs)

if len(results) == 0:
    print("No raid seed")
else:  
    for result in results:
        if result[1] > 0:
            print(f"seed = 0x{result[0]:016X}\nPerfect IVs:{result[1]}")
        else:
            print(f"seed = 0x{result[0]:016X}\n(Shiny locked!) Perfect IVs:{-result[1]}")