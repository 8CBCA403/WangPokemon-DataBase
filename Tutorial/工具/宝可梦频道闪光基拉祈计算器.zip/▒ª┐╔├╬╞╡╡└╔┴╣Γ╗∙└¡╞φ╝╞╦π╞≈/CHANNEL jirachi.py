def xdrng(seed,j):
  k = 0
  while (k <= j):
    newseed = seed
    seed = (0x000043FD*(seed&0xFFFF)+((0x00000003*(seed&0xFFFF)+0x000043FD*int(seed/0x10000))&0xFFFF)*0x10000+0x00269EC3)&(0xFFFFFFFF) #formula
    k += 1
  return seed



natures = ['Hardy  ', 'Lonely ', 'Brave  ', 'Adamant', 'Naughty', 'Bold   ', 'Docile ', 'Relaxed', 'Impish ', 'Lax    ', 'Timid  ', 'Hasty  ', 'Serious', 'Jolly  ', 'Naive  ', 'Modest ', 'Mild   ', 'Quiet  ', 'Bashful', 'Rash   ', 'Calm   ', 'Gentle ', 'Sassy  ', 'Careful', 'Quirky ']


def genlist(seed):
    m = 0
    ms = []
    genlistout = str(seed >> 30)
    F = seed >> 30
    checker = [0,0,0,0]
    backseed = seed
    advance = 8
    while m < 35:
      
      backseed = xdrngr(backseed,0)
      genlistout = str(backseed >> 30) + "|" + genlistout
##      if m == 4:
##        ais = genlistout[5] + genlistout[3] + genlistout[1]
##        advance = 3
##        for i in range(0,len(ais)):
##          if ais[i] == "0" and i < 3:
##            advance = i
##            
##          
##        advance = advance+5
            
      if m == advance-1:
        F = backseed >> 30
        ms = []
        checker = [0,0,0,0]
        genlistout = " M: " + genlistout
      G = backseed >> 30
      if ms == [] and G == F:
        if m >= 8:
          if "XXX" not in genlistout:
            genlistout = "XXX" + genlistout
      if G != 0:
        if checker[G] != 1:
          checker[G] = 1
      if checker == [0,1,1,1]:
        checker = [0,0,0,0]
        ms.append(m)
      m += 1
    return genlistout
    


def rngcheck(rng1,rng2,rng3,rng4,rng5,rng6,rng7,rng8,rng9,rng10,rng11,rng12,i,seed,thresh):
    rng2 = rng2 + 0x80000000
    if rng2 > 0xFFFFFFFF:
        rng2 = rng2 - 0x100000000
    rng1 = str(hex(rng1))[2:]
    rng1 = rng1.replace("L","")
    rng2 = str(hex(rng2))[2:]
    rng2 = rng2.replace("L","")
    rng3 = str(hex(rng3))[2:]
    rng3 = rng3.replace("L","")
    rng4 = str(hex(rng4))[2:]
    rng4 = rng4.replace("L","")
    rng5 = str(hex(rng5))[2:]
    rng5 = rng5.replace("L","")
    rng6 = str(hex(rng6))[2:]
    rng6 = rng6.replace("L","")
    #rng7 = str(hex(rng7))[2:]
    #rng7 = rng7.replace("L","")
    rng8 = str(hex(rng8))[2:]
    rng8 = rng8.replace("L","")
    #rng9 = str(hex(rng9))[2:]
    #rng9 = rng9.replace("L","")
    rng10 = str(hex(rng10))[2:]
    rng10 = rng10.replace("L","")
    rng11 = str(hex(rng11))[2:]
    rng11 = rng11.replace("L","")
    rng12 = str(hex(rng12))[2:]
    rng12 = rng12.replace("L","")

    while len(rng1) < 8:
        rng1 = "0" + rng1
    while len(rng2) < 8:
        rng2 = "0" + rng2
    while len(rng3) < 8:
        rng3 = "0" + rng3
    while len(rng4) < 8:
        rng4 = "0" + rng4    
    while len(rng5) < 8:
        rng5 = "0" + rng5
    while len(rng6) < 8:
        rng6 = "0" + rng6
    #while len(rng7) < 8:
    #    rng7 = "0" + rng7
    while len(rng8) < 8:
        rng8 = "0" + rng8
    #while len(rng9) < 8:
        #rng9 = "0" + rng9
    while len(rng10) < 8:
        rng10 = "0" + rng10
    while len(rng11) < 8:
        rng11 = "0" + rng11
    while len(rng12) < 8:
        rng12 = "0" + rng12
    ivs = [rng7,rng8,rng9,rng10,rng11,rng12]
    IVs = [0,0,0,0,0,0]
    SID = str(int(rng1[0:4],16))
    PID = rng2[0:4] + rng3[0:4]
    XDPID = rng4[0:4] + rng5[0:4]
    XDIV = rng1[0:4]
    for j in range(0,len(ivs)):
        IVs[j] = iv(ivs[j])

    
    if (IVs[3] + IVs[5] + IVs[2] + IVs[1] + IVs[0]) > thresh or (IVs[0] + IVs[2] + IVs[3] + IVs[4] + IVs[5]) > thresh:
        nature = natures[int(PID,16)%25]
        if nature in ['Adamant','Jolly  ','Modest ','Hasty  ','Naive  ','Calm   ','Impish ','Bold   ','Careful','Timid  ','Mild   ','Rash   ']:
          XDIV = xdivs(XDIV)
          genlistout = genlist(seed)
          genlistend = genlistout[-7:]
          advance = 3
          #print genlistend
          if genlistend[0] == "0":
            advance = 7
          if genlistend[2] == "0" and advance == 3:
            advance = 5
          if genlistend[4] == "0" and advance == 3:
            advance = 3
          if genlistend[6] == "0" and advance == 3:
            advance = 3
          mm = genlistout.index('M')
          genlistout = genlistout[:mm+advance] + "T" + genlistout[mm+advance:]
          genlistout = genlistout[2:]
          #print advance
          TidXorSid = int(SID, 10)^40122
          HidXorLid = int(rng2[0:4],16)^int(rng3[0:4],16)
          Judge = TidXorSid^HidXorLid
          if Judge < 8:
            print ("_______________________________________________________________________________")
            print (str(hex(seed))[:-1] + " " + PID +" " + nature + " " +str(IVs[0]) + "/"+str(IVs[1]) + "/"+str(IVs[2]) + "/"+str(IVs[4]) + "/"+str(IVs[5]) + "/"+str(IVs[3]) + " "  + "F: " + str(i+1) + " SID: " + SID + " " + XDPID)
            print ("Probable generation pattern:                                     " + XDIV)
            print (genlistout)
            print ("_______________________________________________________________________________")
         
def xdrngr(seed,j): 
  k = 0
  while (k <= j):
    seedr = (0x00003155*(seed&0xFFFF)+((0x0000B9B3*(seed&0xFFFF)+0x00003155*int(seed/0x10000))&0xFFFF)*0x10000+0xA170F641)&(0xFFFFFFFF) #formula
    seed = seedr
    k += 1
  return seedr
       


def iv(rng):
    rng = rng[0:4]
    rng = bin(int(rng,16))[2:]

    while len(rng) < 16:
        rng = '0' + rng
   # if rng == "0":
    #  rng = rng[1:]
    #  rng = "1" + rng 
    #else:
    #  rng = rng[1:]
   #   rng = "0" + rng
    iv1 = (int(rng[-5:],2))
    iv1 = int(rng,2) >> 11
    return iv1

def xdivs(rng):
  rng = bin(int(rng,16))[2:]
  while len(rng) < 16:
    rng = '0'+rng

  xdiv = str(int(rng[11:16],2)) + "/" + str(int(rng[6:11],2)) + "/" + str(int(rng[1:6],2))
  return xdiv

def __main__(seed,frame,desir,thresh):
  
  i = 0
  while i <  int(frame,10):
        
              
      div = int(desir,10)
      rng7 = xdrng(seed,6)
      rng7 = str(hex(rng7))[2:]
      rng7 = rng7.replace("L","")
      rng9 = xdrng(seed,8)
      rng9 = str(hex(rng9))[2:]
      rng9 = rng9.replace("L","")
      while len(rng7) < 8:
        rng7 = '0' + rng7
      while len(rng9) < 8:
        rng9 = '0' + rng9
        
      testiv = iv(rng7)
      if testiv >= div or div == 32:
        testiv = iv(rng9)
        if testiv >=div or div == 32:
          
          rng1 = xdrng(seed,0) #sid
          rng2 = xdrng(rng1,0) #pidu
          rng3 = xdrng(rng2,0) #pl
          rng4 = xdrng(rng3,0) #spe
          rng5 = xdrng(rng4,0) #spa
          rng6 = xdrng(rng5,0) #spd
          #rng7 = xdrng(seed,6)
          rng8 = xdrng(seed,7) #spa
          #rng9 = xdrng(seed,8)
          rng10 = xdrng(seed,9)
          rng11 = xdrng(rng10,0)
          rng12 = xdrng(rng11,0)#spd
        
          
          rngcheck(rng1,rng2,rng3,rng4,rng5,rng6,rng7,rng8,rng9,rng10,rng11,rng12,i,seed,thresh)
          seed = rng1
          i = i + 1
        else:
          i = i + 1
          seed = xdrng(seed,0)
      else:
        i = i + 1
        seed = xdrng(seed,0)

        
again = "y"
seed = input('Seed = ')
frame = input('Frame = ')
desir = input('IV = ')
seed = int(seed,16)
thresh = int(input("thresh = "))
while again == "y":
  __main__(seed,frame,desir,thresh)
  again = input("again y/n? ")
  if again == "y":
    seed = input('Seed = ')
    seed = int(seed,16)