宝可梦3、4、5代自制配信器，由卧看微尘（Wokann）汉化。
贴吧发布链接：https://tieba.baidu.com/p/7884570848、https://tieba.baidu.com/p/7884601095
B站视频演示链接：https://www.bilibili.com/video/BV1tB4y1S7WT

配信器原作者相关信息：

3代：基于Suloku's Gen 3 Wondercard Editor（ https://github.com/suloku/wc-tool 、https://github.com/projectpokemon/Gen3-WCTool ）；
3代（NDS端）：基于mrhappyasthma's NDSEventTool.nds(https://github.com/mrhappyasthma/NDSEventTool.nds)及suloku's savegame-manager
（https://github.com/suloku/savegame-manager/tree/mystery-event）
4代：基于MicShadow's GEN 4 Wondercard Distribution Patcher（http://gbatemp.net/index.php?showtopic=92283&st=15 ）；
5代（推荐）：基于KaroWAR‘s GEN 5 Liberty Ticket Distribution Card Editor（https://gbatemp.net/threads/liberty-ticket-distribution-card-editor.283345/）；
5代（兼容可能不佳）：基于PlasticJustice‘s Gen 5 Pokémon Distribution ROM Creator（https://github.com/PlasticJustice/PKMG5DC）；


本人汉化配信器项目地址：

3代：https://github.com/Wokann/GEN3_WCTool_CHS；
3代（NDS端）：https://github.com/Wokann/GEN3_NDSMysteryGiftTool_CHS
4代：https://github.com/Wokann/GEN4_WCDPatcher_CHS；
5代：https://github.com/Wokann/GEN5_LTDCE_CHS和https://github.com/Wokann/GEN5_PKMG5DC_CHS；

GEN3自制配信器（Mystery Gift Tool）：
功能介绍：
1、直接配信合法船票（限定游戏版本及语言，相关内容可看本人帖子https://tieba.baidu.com/p/6517460676）；
2、自定义配信神秘礼物、神秘新闻、神秘事件、e卡训练家、e卡树果；
3、自定义编辑神秘卡片、神秘新闻、神秘事件、e卡训练家、e卡树果；
4、查看编辑装饰物品；
5、查看编辑电视节目及大量出现情况。

GEN3自制配信器（NDS Mystery Gift Tool）：
功能介绍：
1、直接配信合法船票（限定游戏版本及语言，相关内容可看本人帖子https://tieba.baidu.com/p/6517460676）；
2、美版绿宝石配信非法古航海图；
注：日版绿宝石无法直接配信无限船票，需要日版红蓝宝石配信后再混合存档获得。

GEN4自制配信器（Wondercard Distribution Patcher）：
功能介绍：
1、基于官方2008代欧奇希斯配信卡带ROM，及配信文件，制作自定义配信ROM；
2、通过控制符，批量生成自制配信ROM（详见项目文件内的readme）。

【推荐】GEN5自制配信器（Liberty Ticket Distribution Card Editor）：
功能介绍：
1、基于官方自由船票配信卡带ROM，及配信文件，制作自定义配信ROM。

【兼容性可能不佳】GEN5自制配信器（Pokémon Distribution ROM Creator）：
功能介绍：
1、基于官方自由船票配信卡带ROM，及配信文件，制作自定义配信ROM；
2、自定义编辑配信宝可梦、道具、释出之力。
