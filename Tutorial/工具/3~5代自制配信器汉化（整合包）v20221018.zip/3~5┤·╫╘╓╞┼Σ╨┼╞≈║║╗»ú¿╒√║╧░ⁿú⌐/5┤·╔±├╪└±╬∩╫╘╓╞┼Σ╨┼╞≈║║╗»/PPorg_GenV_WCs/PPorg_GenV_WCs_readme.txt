Generation V 
Pokemon Black, White, Black 2, and White 2 Versions
Event Pokemon Collection
from projectpokemon.org

Full Event Gallery:
http://projectpokemon.org/events

This collection will be constantly updated.
For the latest version and information, see:
http://projectpokemon.org/forums/showthread.php?15282-Gen-V-Event-Collection-and-Contribution-Thread

We don't restrict the usage of these files, but if you host them somewhere else, we ask you to credit the site where it was obtained (here, projectpokemon.org).  We ask this partially as a courtesy to those who contributed, those worked to compile and organize this collection, and due to the fact that the collection is coninuously being updated.