WC4: Debug Azure Flute + Infernape Test Card ᅟᅟᅟ
from projectpokemon.org

https://projectpokemon.org/home/files/file/1853-wc4-debug-azure-flute-infernape-test-card/

About This File
The Key Item Azure Flute, which would allow a holy encounter with Arceus, was never legitimately released to players.
However, found within a file (decchi.bin), that was found in Generation 4 distribution carts for Deoxys, (Uploader's note: file-ception at it's finest)
It appears that an Azure Flute distribution was being tested via slot-2 distribution.

The nature of the slot-2 distribution game that this wonder card was obtained from, only allowed distribution to JPN games.
The distribution text seems to be reusing the distribution text for a Generation 3 Old Sea Chart distribution.

It was also discovered by @Deoxyz that changing the distribution type from Key Item to Pokemon, will show complete information for an Infernape to be received.

It was also discovered by @DeadSkullzJr that the copy of the wonder card in the game (seen via hex) slightly differs from the wonder card that was received. The one in the game has a redistribution count. Presumably this copy has the redistribution count, but the received one does not, because it does not allow players who received a copy to redistribute.

The Key Item Azure Flute wonder card (.pcd), Modified to show Infernape (.pcd) and the Infernape (.pkm) are up for download.
[We will not host the decchi.bin or Distribution Roms for the Deoxys]

 

Update: Even though the remakes Brilliant Diamond and Shining Pearl included a way to get Azure Flute and the Hall of Origin Arceus encounter, owning the Gen 4 HoO Arceus would still be illegal.

 

File Info
Gen 4 Decchi - Azure Flute.pcd - Extracted from save that received it. The one without redistribution count.
Gen 4 Decchi - Azure Flute (Hex Extracted, Redistribution count).pcd - Hex extracted from the game. The one with redistribution count.
Gen 4 Decchi - Infernape.pcd - The receiving type was modified to show the Infernape gift hiding within
Gen 4 Decchi - Infernape.pkm - A pk4 file of the extracted Infernape.