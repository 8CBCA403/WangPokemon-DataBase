此文件来自于https://projectpokemon.org/home/forums/topic/37579-lock-capsule-hgss/
由#8楼Ahito95所制作。