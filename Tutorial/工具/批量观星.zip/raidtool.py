from G8RNG import XOROSHIRO,Raid
import xlrd,openpyxl

def str2hex(s):
    odata = 0;
    su =s.upper()
    for c in su:
        tmp=ord(c)
        if tmp <= ord('9') :
            odata = odata << 4
            odata += tmp - ord('0')
        elif ord('A') <= tmp <= ord('F'):
            odata = odata << 4
            odata += tmp - ord('A') + 10
    return odata

path="d:\\观星数据表3.0.xlsx"
output_path="d:\\观星数据表12.24.xlsx"
workbook=openpyxl.load_workbook(path)
worksheet=workbook.worksheets[1]
data = xlrd.open_workbook(path)
table=data.sheets()[1]
iimax=table.ncols
for ii in range(1,iimax,1):
#for ii in range(1,2,1):
	# print(ii)
	#print(str(table.cell(3,ii)))
	#print(str(table.cell(4,ii)))
	if table.cell_value(3,ii) == 0 or table.cell_value(3,ii) == 0.0:
		break
	EC = int(str(str2hex(str(table.cell(3,ii).value))))
	PID = int(str(str2hex(str(table.cell(4,ii).value))))
	IVs = [int(table.cell(5,ii).value),int(table.cell(6,ii).value),int(table.cell(7,ii).value),int(table.cell(8,ii).value),int(table.cell(9,ii).value),int(table.cell(10,ii).value)]

	output_frames=''
	output_shiny=''
	output_ability=''
	output_gender=''
	#PID = 0x93F4D34B
	#EC = 0xC4A8A10D
	#IVs = [31,31,31,31,6,31]
	usefilters = True
	MaxResults = 5000

	shinyCount = 0

	# Desired IVs
	V6 = [31,31,31,31,31,31]
	S0 = [31,31,31,31,31,00]
	A0 = [31,00,31,31,31,31]

	# Find seeds
	results = Raid.getseeds(EC,PID,IVs)
	print(f"\n"+table.cell(1,ii).value+" Results:")
	if len(results) == 0:
		worksheet.cell(17,ii+1,'No raid seed')
		print("No raid seed")
	else:  
		for result in results:
			if result[1] > 0:
				print(f"seed = 0x{result[0]:016X}\nPerfect IVs:{result[1]}")
				r = Raid(result[0],flawlessiv = result[1], HA = 0, RandomGender = 0)
				r.print()
			else:
				print(f"seed = 0x{result[0]:016X}\n(Shiny locked!) Perfect IVs:{-result[1]}")
				r = Raid(result[0],flawlessiv = -result[1], HA = 1, RandomGender = 0)
				r.print()

	# Calc frames
	if len(results) > 0:
		#print(f"闪光信息:")
		seed = results[0][0]
		i = 0
		while i < MaxResults:
			r = Raid(seed, flawlessiv = 4, HA = 1, RandomGender = 1)
			seed = XOROSHIRO(seed).next()
			if usefilters:
				#if r.ShinyType != 'None' or r.IVs == V6 or r.IVs == S0 or r.IVs == A0:
				if r.ShinyType != 'None':
					print(i)
					r.print()
					output_frames=output_frames+str(i)+' '
					output_shiny=output_shiny+r.ShinyType+' '
					output_ability=output_ability+str(r.Ability)+' '
					output_gender=output_gender+str(r.Gender)+' '
					shinyCount += 1
					if shinyCount == 3:
						shinyCount = 0
						break
			else:
				r.print()
			i += 1
		if output_frames=='':
			output_frames=str(MaxResults)+'帧内无闪'
		worksheet.cell(17,ii+1,output_frames)
		worksheet.cell(18,ii+1,output_shiny)
		worksheet.cell(19,ii+1,output_ability)
		worksheet.cell(20,ii+1,output_gender)
workbook.save(filename=output_path)
